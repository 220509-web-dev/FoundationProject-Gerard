--Task _ Select All records from the employee table. 
select * from "Employee";

-- Task - Select All records from the Employee table where the last name is King.
select * from "Employee" where "LastName" = 'King';

-- Task - Select All records from the Employee table where first name is Andrew and Reportsto is null.
select * from "Employee" where "FirstName" = 'Andrew' and "Employee"."ReportsTo" is null;


